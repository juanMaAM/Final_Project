
package finalproject;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class FinalProject {

    
    public static void main(String[] args) {
        FinalProject() ;
    }
    



    
    
        public static void FinalProject() {
        
        String usuario = "";
        String contraseña = null;
        String Curp = null;
        int edad = 0; 
        int telefono = 0; 
        int sueldo = 0;
        String direccion = null;
        double estatura = 0; 
        char genero = 0;
        String nombre = null;
        String estudios = null;
        int familiares = 0; 
        int opcion;

        do {
            opcion = Integer.parseInt(JOptionPane.showInputDialog(null,

                    "   ELIJA LA OPCION QUE NECESITA UTILIZAR  \n" +
                            
                            "1.- Iniciar sesion \n" +

                            "2.- Captura de datos \n" +

                            "3.- Consulta de datos \n" +

                            "4.- Finalizar \n" +

                            "INGRESE UNA OPCION(1-4)",
                    "Base de datos", JOptionPane.QUESTION_MESSAGE));
            switch (opcion) {
                
                case 1:
                
                Scanner in = new Scanner(System.in);    
          
                System.out.println("Ingrese el Usuario: ");
                usuario = in.nextLine();
                System.out.println("");

                System.out.println("Ingrese la Contraseña: ");
                contraseña = in.nextLine();
                System.out.println("");
                   
                 
                 break;   
                    
                    
                    
                    
                    
            case 2:
                Scanner teclado = new Scanner(System.in);
                System.out.print("Ingrese la direccion: ");
                direccion = teclado.nextLine();

                System.out.print("Ingrese su Curp: ");
                Curp = teclado.next();

                System.out.print("Ingrese el nombre: ");
                teclado.nextLine();
                nombre = teclado.nextLine();

                System.out.print("Ingrese la edad: ");
                edad = teclado.nextInt();

                System.out.print("Ingrese el telefono: ");
                telefono = teclado.nextInt();

                System.out.print("Ingrese el sueldo: ");
                sueldo = teclado.nextInt();

                System.out.print("Ingrese la estatura: ");
                estatura = teclado.nextDouble();

                System.out.print("Ingrese los estudios: ");
                teclado.nextLine();
                estudios = teclado.nextLine();

                System.out.print("Ingrese la cantidad de familiares: ");
                familiares = teclado.nextInt();

                System.out.print("Genero (Masculino o femenino): ");
                genero = teclado.next().charAt(0);

               
                teclado.close();
                break;
            case 3:
                
                if (genero == 'm' || genero == 'M') {
                    System.out.println("\nSeñor " + nombre + ",\nSu Curp es: " + Curp + ",\nSu información extraída de la base de datos es la siguiente:");
                    System.out.println("Tiene " + edad + " años de edad,\nvive en: " + direccion + ",\nSu teléfono es: " + telefono + ",\nmide " + estatura + " metros de estatura"
                            + ",\nsu sueldo es de " + sueldo + ".\nGrado de estudio: " + estudios + " y tiene " + familiares + " familiares.");
                } else { 
                    System.out.println("\nSeñora " + nombre + ",\nSu Curp es: " + Curp + ",\nSu información extraída de la base de datos es la siguiente:");
                    System.out.println("Tiene " + edad + " años de edad,\nvive en: " + direccion + ",\nSu teléfono es: " + telefono + ",\nmide " + estatura + " metros de estatura"
                            + ",\nsu sueldo es de " + sueldo  + ".\nGrado de estudio: " + estudios + " y tiene " + familiares + " familiares.");
                }
       break;

            case 4:
                JOptionPane.showMessageDialog(null, "QUE TENGA BUEN DIA");
                System.exit(0);
                break;
            default:
                JOptionPane.showMessageDialog(null, "ELIJA UNA OPCION VALIDA \n", "ERROR DE OPCION",
                        JOptionPane.WARNING_MESSAGE);
            }
        } while (opcion != 3);
    }

}
